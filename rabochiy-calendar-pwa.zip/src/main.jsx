import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  CalendarDays, Wallet, ChartNoAxesColumn, Settings, ChevronLeft, ChevronRight,
  Sun, Moon, Download, Clock3, BriefcaseBusiness, Coffee, Check, Smartphone,
  CalendarCheck, CircleHelp, RotateCcw
} from 'lucide-react';
import './styles.css';

const RATE = 8300;
const pad = (n) => String(n).padStart(2, '0');
const keyOf = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const fromKey = (s) => { const [y,m,d] = s.split('-').map(Number); return new Date(y, m - 1, d, 12); };
const addDays = (date, amount) => { const d = new Date(date); d.setDate(d.getDate() + amount); return d; };
const monthStart = (d) => new Date(d.getFullYear(), d.getMonth(), 1, 12);
const monthName = (d) => d.toLocaleDateString('ru-RU', { month: 'long', year: 'numeric' });
const prettyDate = (d, options = { day: 'numeric', month: 'long' }) => d.toLocaleDateString('ru-RU', options);
const money = (n) => new Intl.NumberFormat('ru-RU', { style: 'currency', currency: 'RUB', maximumFractionDigits: 0 }).format(n);

function isWorkday(date, anchorKey) {
  const anchor = fromKey(anchorKey);
  const diff = Math.round((new Date(date.getFullYear(), date.getMonth(), date.getDate(), 12) - anchor) / 86400000);
  return ((diff % 4) + 4) % 4 < 2;
}
function periodWorkdays(start, end, anchor) {
  let count = 0;
  for (let d = new Date(start); d <= end; d = addDays(d, 1)) if (isWorkday(d, anchor)) count++;
  return count;
}
function App() {
  const today = new Date();
  const [splash, setSplash] = useState(true);
  const [anchor, setAnchor] = useState(() => localStorage.getItem('wc-anchor') || keyOf(today));
  const [anchorMode, setAnchorMode] = useState(() => localStorage.getItem('wc-anchor-mode') || 'today');
  const [month, setMonth] = useState(monthStart(today));
  const [selected, setSelected] = useState(keyOf(today));
  const [tab, setTab] = useState('calendar');
  const [dark, setDark] = useState(() => localStorage.getItem('wc-dark') === 'true');
  const [installPrompt, setInstallPrompt] = useState(null);
  const [installed, setInstalled] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setSplash(false), 1250);
    return () => clearTimeout(t);
  }, []);
  useEffect(() => {
    localStorage.setItem('wc-anchor', anchor);
    localStorage.setItem('wc-anchor-mode', anchorMode);
  }, [anchor, anchorMode]);
  useEffect(() => {
    localStorage.setItem('wc-dark', String(dark));
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  }, [dark]);
  useEffect(() => {
    if ('serviceWorker' in navigator && import.meta.env.PROD) {
      navigator.serviceWorker.register('/sw.js').catch((err) => console.warn('SW registration failed', err));
    }
    const onPrompt = (e) => { e.preventDefault(); setInstallPrompt(e); };
    const onInstalled = () => { setInstalled(true); setInstallPrompt(null); };
    window.addEventListener('beforeinstallprompt', onPrompt);
    window.addEventListener('appinstalled', onInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', onPrompt);
      window.removeEventListener('appinstalled', onInstalled);
    };
  }, []);

  const monthDays = useMemo(() => {
    const first = monthStart(month);
    const offset = (first.getDay() + 6) % 7;
    const start = addDays(first, -offset);
    return Array.from({ length: 42 }, (_, i) => addDays(start, i));
  }, [month]);
  const selectedDate = fromKey(selected);
  const selectedIsWork = isWorkday(selectedDate, anchor);
  const currentMonthWorkdays = useMemo(() => {
    const start = monthStart(month);
    const end = new Date(month.getFullYear(), month.getMonth() + 1, 0, 12);
    return periodWorkdays(start, end, anchor);
  }, [month, anchor]);
  const monthlyTotal = currentMonthWorkdays * RATE;
  const pay10Period = useMemo(() => {
    const payDate = new Date(month.getFullYear(), month.getMonth(), 10, 12);
    const prevEnd = new Date(month.getFullYear(), month.getMonth(), 0, 12);
    const prevStart = new Date(prevEnd.getFullYear(), prevEnd.getMonth(), 16, 12);
    return { date: payDate, amount: periodWorkdays(prevStart, prevEnd, anchor) * RATE, label: '16 — последнее число прошлого месяца' };
  }, [month, anchor]);
  const pay25Period = useMemo(() => {
    const payDate = new Date(month.getFullYear(), month.getMonth(), 25, 12);
    const start = new Date(month.getFullYear(), month.getMonth(), 1, 12);
    const end = new Date(month.getFullYear(), month.getMonth(), 15, 12);
    return { date: payDate, amount: periodWorkdays(start, end, anchor) * RATE, label: '1 — 15 число текущего месяца' };
  }, [month, anchor]);

  const changeMonth = (delta) => setMonth(new Date(month.getFullYear(), month.getMonth() + delta, 1, 12));
  const chooseAnchor = (value, mode = 'custom') => {
    setAnchor(value);
    setAnchorMode(mode);
  };
  const handleInstall = async () => {
    if (!installPrompt) return;
    installPrompt.prompt();
    await installPrompt.userChoice;
    setInstallPrompt(null);
  };

  if (splash) return <div className="splash">
    <div className="splash-mark"><CalendarDays size={38} strokeWidth={2.3} /></div>
    <h1>Рабочий календарь</h1>
    <p>Твой график. Твоя зарплата.</p>
    <div className="loader"><span /></div>
  </div>;

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand"><div className="brand-mark"><CalendarDays size={23} /></div><div><div className="brand-title">Рабочий календарь</div><div className="brand-sub">График 2/2 · ставка {money(RATE)} за смену</div></div></div>
      <button className="icon-btn" aria-label="Переключить тему" onClick={() => setDark(!dark)}>{dark ? <Sun size={19}/> : <Moon size={19}/>}</button>
    </header>

    {tab === 'calendar' && <main className="page fade-in">
      <section className="hero-card">
        <div><span className="eyebrow">СЕГОДНЯ · {prettyDate(today, { weekday: 'long', day: 'numeric', month: 'long' })}</span><h2>{isWorkday(today, anchor) ? 'Сегодня рабочая смена' : 'Сегодня день отдыха'}</h2><p>{isWorkday(today, anchor) ? 'Отличного рабочего дня — заработок уже учитывается.' : 'Восстановись и набери сил перед следующей сменой.'}</p></div>
        <div className={`hero-icon ${isWorkday(today, anchor) ? 'work' : 'rest'}`}>{isWorkday(today, anchor) ? <BriefcaseBusiness size={27}/> : <Coffee size={27}/>}</div>
      </section>

      <section className="panel calendar-panel">
        <div className="panel-heading">
          <div><h2 className="month-title">{monthName(month)}</h2><span className="muted">{currentMonthWorkdays} смен · {money(monthlyTotal)} за месяц</span></div>
          <div className="month-nav"><button className="icon-btn small" onClick={() => changeMonth(-1)} aria-label="Предыдущий месяц"><ChevronLeft size={18}/></button><button className="icon-btn small" onClick={() => changeMonth(1)} aria-label="Следующий месяц"><ChevronRight size={18}/></button></div>
        </div>
        <div className="weekdays">{['Пн','Вт','Ср','Чт','Пт','Сб','Вс'].map((d) => <span key={d}>{d}</span>)}</div>
        <div className="calendar-grid">{monthDays.map((d) => {
          const k = keyOf(d), inMonth = d.getMonth() === month.getMonth(), work = isWorkday(d, anchor), active = selected === k;
          return <button key={k} className={`day ${!inMonth ? 'outside' : ''} ${work ? 'day-work' : 'day-rest'} ${active ? 'selected' : ''} ${k === keyOf(today) ? 'today' : ''}`} onClick={() => setSelected(k)} aria-label={`${prettyDate(d)}, ${work ? 'рабочий день' : 'выходной'}`}>
            <span>{d.getDate()}</span>{inMonth && <i className="day-dot"/>}
          </button>;
        })}</div>
        <div className="legend"><span><i className="legend-dot work-dot"/>Рабочий день</span><span><i className="legend-dot rest-dot"/>Выходной</span><span><i className="legend-dot selected-dot"/>Выбранная дата</span></div>
      </section>

      <section className="panel selected-card">
        <div className="selected-date-icon">{selectedIsWork ? <BriefcaseBusiness size={20}/> : <Coffee size={20}/>}</div>
        <div className="selected-copy"><span className="muted">Выбранная дата</span><h3>{prettyDate(selectedDate, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</h3><p>{selectedIsWork ? `Рабочая смена · начисление ${money(RATE)}` : 'День отдыха · начислений нет'}</p></div>
        <span className={`status-pill ${selectedIsWork ? 'pill-work' : 'pill-rest'}`}>{selectedIsWork ? 'Работа' : 'Отдых'}</span>
      </section>

      <section className="section-title"><div><h2>Ближайшие выплаты</h2><p>Расчёт по фактически запланированным сменам</p></div><button className="text-btn" onClick={() => setTab('payments')}>Все выплаты <ChevronRight size={15}/></button></section>
      <div className="payment-preview">
        <PaymentMini item={pay25Period} />
        <PaymentMini item={pay10Period} />
      </div>
    </main>}

    {tab === 'payments' && <main className="page fade-in">
      <section className="page-intro"><span className="eyebrow">ФИНАНСЫ</span><h1>Выплаты и зарплата</h1><p>Суммы рассчитаны по графику 2/2 и ставке {money(RATE)} за рабочий день.</p></section>
      <section className="income-card"><div className="income-top"><span>Заработок за {monthName(month)}</span><Wallet size={20}/></div><strong>{money(monthlyTotal)}</strong><div className="income-meta"><span>{currentMonthWorkdays} рабочих смен</span><span>{money(RATE)} / смена</span></div><div className="progress"><span style={{width: `${Math.min(100, currentMonthWorkdays / 16 * 100)}%`}}/></div></section>
      <section className="section-title"><div><h2>График выплат</h2><p>{monthName(month)}</p></div><div className="month-nav"><button className="icon-btn small" onClick={() => changeMonth(-1)}><ChevronLeft size={18}/></button><button className="icon-btn small" onClick={() => changeMonth(1)}><ChevronRight size={18}/></button></div></section>
      <PaymentLarge item={pay25Period} number="25" title="Первая половина месяца" />
      <PaymentLarge item={pay10Period} number="10" title="Вторая половина прошлого месяца" />
      <div className="note"><CircleHelp size={18}/><p>Это плановый расчёт по календарю. Он не учитывает налоги, премии, больничные и изменения фактически отработанных смен.</p></div>
    </main>}

    {tab === 'stats' && <main className="page fade-in">
      <section className="page-intro"><span className="eyebrow">ОБЗОР</span><h1>Статистика</h1><p>Плановый заработок и рабочие дни за выбранный месяц.</p></section>
      <section className="stats-grid"><div className="stat-card"><span className="stat-icon blue"><Wallet size={18}/></span><span className="muted">Заработок</span><strong>{money(monthlyTotal)}</strong><small>{monthName(month)}</small></div><div className="stat-card"><span className="stat-icon green"><BriefcaseBusiness size={18}/></span><span className="muted">Рабочие дни</span><strong>{currentMonthWorkdays}</strong><small>по графику 2/2</small></div><div className="stat-card"><span className="stat-icon purple"><Coffee size={18}/></span><span className="muted">Дни отдыха</span><strong>{new Date(month.getFullYear(), month.getMonth()+1, 0).getDate() - currentMonthWorkdays}</strong><small>в этом месяце</small></div><div className="stat-card"><span className="stat-icon orange"><Clock3 size={18}/></span><span className="muted">Ставка за день</span><strong>{money(RATE)}</strong><small>фиксированная</small></div></section>
      <section className="panel"><div className="panel-heading"><div><h2>План по дням</h2><span className="muted">{monthName(month)}</span></div><div className="month-nav"><button className="icon-btn small" onClick={() => changeMonth(-1)}><ChevronLeft size={18}/></button><button className="icon-btn small" onClick={() => changeMonth(1)}><ChevronRight size={18}/></button></div></div><div className="bar-chart">{Array.from({length: new Date(month.getFullYear(), month.getMonth()+1, 0).getDate()}, (_, i) => { const d = new Date(month.getFullYear(), month.getMonth(), i+1, 12); const work = isWorkday(d, anchor); return <div className="bar-column" key={i} title={`${i+1}: ${work ? 'рабочий день' : 'выходной'}`}><div className={`bar ${work ? 'bar-work' : 'bar-rest'}`} style={{height: work ? '100%' : '25%'}}/><span>{i+1}</span></div>; })}</div><div className="chart-legend"><span><i className="legend-dot work-dot"/>Рабочая смена</span><span><i className="legend-dot rest-dot"/>Отдых</span></div></section>
    </main>}

    {tab === 'settings' && <main className="page fade-in">
      <section className="page-intro"><span className="eyebrow">ПЕРСОНАЛИЗАЦИЯ</span><h1>Настройки графика</h1><p>Укажи дату, которая является первым из двух рабочих дней. Приложение построит цикл 2/2 на любые даты календаря.</p></section>
      <section className="panel settings-panel">
        <div className="setting-row"><div className="setting-icon"><CalendarCheck size={20}/></div><div className="setting-copy"><h3>Отправная точка</h3><p>Первый рабочий день цикла 2/2</p></div></div>
        <label className="field-label" htmlFor="anchor-date">Дата первого рабочего дня</label>
        <input id="anchor-date" className="date-input" type="date" value={anchor} onChange={(e) => chooseAnchor(e.target.value)} />
        <div className="quick-options"><button className={`quick-option ${anchor === keyOf(today) ? 'active' : ''}`} onClick={() => chooseAnchor(keyOf(today), 'today')}>Сегодня — работа</button><button className={`quick-option ${anchor === keyOf(addDays(today, -1)) ? 'active' : ''}`} onClick={() => chooseAnchor(keyOf(addDays(today, -1)), 'yesterday')}>Вчера — работа</button></div>
        <div className="info-box"><Check size={17}/><p>Изменения применяются сразу: календарь, количество смен, статистика и суммы выплат пересчитываются автоматически.</p></div>
      </section>
      <section className="panel settings-panel">
        <div className="setting-row"><div className="setting-icon"><Sun size={20}/></div><div className="setting-copy"><h3>Внешний вид</h3><p>Выбери комфортную тему приложения</p></div></div>
        <div className="theme-options"><button className={`theme-option ${!dark ? 'active' : ''}`} onClick={() => setDark(false)}><Sun size={18}/>Светлая</button><button className={`theme-option ${dark ? 'active' : ''}`} onClick={() => setDark(true)}><Moon size={18}/>Тёмная</button></div>
      </section>
      <section className="panel settings-panel">
        <div className="setting-row"><div className="setting-icon"><Smartphone size={20}/></div><div className="setting-copy"><h3>Установка приложения</h3><p>Добавь календарь на главный экран для быстрого доступа.</p></div></div>
        {installPrompt ? <button className="primary-btn full" onClick={handleInstall}><Download size={17}/> Установить приложение</button> : <p className="install-hint">{installed ? 'Приложение установлено на устройство.' : 'Если кнопка установки не появилась, открой меню браузера и выбери «Установить приложение» или «Добавить на главный экран». Для установки нужен HTTPS (или localhost).'}</p>}
      </section>
      <button className="reset-btn" onClick={() => { chooseAnchor(keyOf(today), 'today'); setMonth(monthStart(today)); setSelected(keyOf(today)); }}><RotateCcw size={16}/> Сбросить к сегодняшней дате</button>
    </main>}

    <nav className="bottom-nav">
      <NavItem active={tab==='calendar'} icon={<CalendarDays size={20}/>} label="Календарь" onClick={() => setTab('calendar')}/>
      <NavItem active={tab==='payments'} icon={<Wallet size={20}/>} label="Выплаты" onClick={() => setTab('payments')}/>
      <NavItem active={tab==='stats'} icon={<ChartNoAxesColumn size={20}/>} label="Статистика" onClick={() => setTab('stats')}/>
      <NavItem active={tab==='settings'} icon={<Settings size={20}/>} label="Ещё" onClick={() => setTab('settings')}/>
    </nav>
  </div>;
}

function NavItem({active, icon, label, onClick}) {
  return <button className={`nav-item ${active ? 'active' : ''}`} onClick={onClick}>{icon}<span>{label}</span></button>;
}
function PaymentMini({item}) {
  return <button className="payment-mini" onClick={() => {}}><div className="mini-date"><CalendarDays size={16}/><span>{prettyDate(item.date, {day:'numeric', month:'short'})}</span></div><strong>{money(item.amount)}</strong><small>{item.label}</small></button>;
}
function PaymentLarge({item, number, title}) {
  return <section className="panel payout-card"><div className="payout-date"><div className="date-number">{number}</div><div><h3>{title}</h3><p>{prettyDate(item.date, {day:'numeric', month:'long'})} · дата выплаты</p></div></div><strong className="payout-amount">{money(item.amount)}</strong><div className="payout-divider"/><div className="payout-bottom"><span>Расчётный период</span><span>{item.label}</span></div><div className="payout-bottom"><span>Ставка</span><span>{money(RATE)} / смена</span></div></section>;
}

createRoot(document.getElementById('root')).render(<React.StrictMode><App /></React.StrictMode>);